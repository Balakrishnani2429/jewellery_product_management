<?php $this->load->view('layouts/header'); ?>

    <h2>Product List <a href="<?= site_url('products/add') ?>" class="btn btn-primary pull-right">Add Product</a></h2>
    <table id="products" class="display">
        <thead>
            <tr>
                <th>Name</th><th>Description</th><th>Price</th><th>Category</th><th>Image</th>
            </tr>
        </thead>
    </table>

    <script src="//code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#products').DataTable({
                "ajax": "<?= site_url('products/get_products') ?>",
                "columns": [
                    { "data": "name" },
                    { "data": "description" },
                    { "data": "price" },
                    { "data": "category" },
                    {
                        "data": "image",
                        "render": function(data){
                            return '<img src="/uploads/'+data+'" width="60">';
                        }
                    }
                ]
            });
        });
    </script>
<?php $this->load->view('layouts/footer'); ?>
