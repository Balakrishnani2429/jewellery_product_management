<?php $this->load->view('layouts/header'); ?>

    <h2>Add Product</h2>
    <form method="post" action="<?= site_url('products/save') ?>" enctype="multipart/form-data">
        <div class="form-group"><input type="text" name="name" class="form-control" placeholder="Product Name" required></div>
        <div class="form-group"><textarea name="description" class="form-control" placeholder="Description"></textarea></div>
        <div class="form-group"><input type="number" step="0.01" name="price" class="form-control" placeholder="Price" required></div>
        <div class="form-group">
            <select name="category" class="form-control" required>
                <option value="">Select Category</option>
                <?php foreach($categories as $cat): ?>
                    <option value="<?= $cat->id ?>"><?= $cat->name ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group"><input type="file" name="image" class="form-control"></div>
        <button class="btn btn-success">Save</button>
    </form>
    <?php $this->load->view('layouts/footer'); ?>
