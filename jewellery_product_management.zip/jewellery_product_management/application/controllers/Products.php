<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

    public function __construct() {
        parent::__construct();
        if (!$this->session->userdata('user_id')) redirect('auth');
        $this->load->model('Product_model');
    }

    public function index() {
        $this->load->view('products/list');
    }

    public function get_products() {
        echo json_encode($this->Product_model->get_all_products());
    }

    public function add() {
        $data['categories'] = $this->Product_model->get_categories();
        $this->load->view('products/form', $data);
    }

    public function save() {
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $this->load->library('upload', $config);

        $image = '';
        if ($this->upload->do_upload('image')) {
            $upload_data = $this->upload->data();
            $this->_resize_image($upload_data['full_path']);
            $image = $upload_data['file_name'];
        }

        $this->Product_model->insert([
            'name' => $this->input->post('name'),
            'description' => $this->input->post('description'),
            'price' => $this->input->post('price'),
            'category_id' => $this->input->post('category'),
            'image' => $image
        ]);

        redirect('products');
    }

    private function _resize_image($path) {
        $config['image_library'] = 'gd2';
        $config['source_image'] = $path;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = 500;
        $config['height'] = 500;
        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
    }
}
