<?php

// application/models/Product_model.php
class Product_model extends CI_Model {

    public function get_all_products() {
        $query = $this->db->select('p.*, c.name as category')
            ->from('products p')
            ->join('categories c', 'p.category_id = c.id')
            ->get();
        return ['data' => $query->result()];
    }

    public function get_categories() {
        return $this->db->get('categories')->result();
    }

    public function insert($data) {
        $this->db->insert('products', $data);
    }
}
